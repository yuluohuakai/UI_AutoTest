
class Constant:
    def __init__(self):
        self.username_1 = "test1"
        self.password_1 = "Pr0d1234"

    def getUsername_1(self):
        return self.username_1

    def getPassword_1(selfs):
        return selfs.password_1
