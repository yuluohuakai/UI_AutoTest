import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import Tool

#--------------------Scenario:选择未接受的任务--------------------
@When(u"选择未接受的任务")
def step_impl(context):

    try:
        tab_1 = context.driver.find_elements_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='已接受']/.."))
        tab_2 = tab_1[0]
        tab_2.click()
    except Exception as e:
        print(e)

@When(u"在详情页面点击接受")
def step_impl(context):
    try:
        accept = context.driver.find_element_by_id("com.huawei.ioc:id/tv_accept")
        accept.click()
    except Exception as e:
        print(e)
    context.driver.implicitly_wait(0.5)


@Then(u"进入任务详情界面")
def step_impl(context):
    context.driver.implicitly_wait(0.5)


#--------------------Scenario:填写现场反馈--------------------
@When(u"点击现场反馈选项")
def step_impl(context):
    context.driver.implicitly_wait(3)
    try:
        tab_3 = context.driver.find_element_by_xpath(("//android.widget.TextView[@text='真实事件，已处理']"))
        tab_3.click()
    except Exception as e:
        print(e)

@Then(u"勾选选项")
def step_impl(context):
    context.driver.implicitly_wait(1)

'''
Scenario:添加照片
      When 点击添加照片按钮
      When 点击照片添加
      Then 界面上含有照片
#--------------------Scenario:添加照片--------------------
@When(u"点击添加照片按钮")
def step_impl(context):

    try:
        add_photo = context.driver.find_element_by_id(("com.huawei.ioc:id/iv_item_photo"))
        add_photo.click()
    except Exception as e:
        print(e)

    try:
        choose_albu = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_choose_album"))
        choose_albu.click()
    except Exception as e:
        print(e)

@When(u"点击照片添加")
def step_impl(context):
    try:
        select_icon = context.driver.find_elements_by_xpath(
            ("//android.widget.ImageView[@resource-id='com.huawei.ioc:id/iv_select_icon']"))
        select_photo = select_icon[0]
        select_photo.click()
    except Exception as e:
        print(e)

    try:
        right = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_right"))
        right.click()
    except Exception as e:
        print(e)

@Then(u"界面上含有照片")
def step_impl(context):
    context.driver.implicitly_wait(1)
'''

#--------------------Scenario:填写备注--------------------
@When(u"填写备注")
def step_impl(context):
    Tool.BaseClass.swipeUp(context.driver)
    try:
        upload_des = context.driver.find_element_by_id(("com.huawei.ioc:id/et_upload_des"))
        upload_des.send_keys("完成")
    except Exception as e:
        print(e)
    context.driver.implicitly_wait(0.5)

@Then(u"界面上出现备注信息")
def step_impl(context):
    context.driver.implicitly_wait(1)


#--------------------Scenario:完成任务--------------------
@When(u"点击完成")
def step_impl(context):

    try:
        finish = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_finish"))
        finish.click()
    except Exception as e:
        print(e)

@Then(u"返回到任务列表界面")
def step_impl(context):
    context.driver.implicitly_wait(1)