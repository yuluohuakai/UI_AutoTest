import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import Tool


#--------------------Scenario:用户A在登录界面正常登录--------------------
@Given(u"用户A输入正确用户名和密码")
def step_impl(context):
    time.sleep(3)
    user_name = WebDriverWait(context.driver, 5, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
    user_name.clear()
    user_name.send_keys("c84108434")
    password = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
    password.clear()
    password.send_keys("qwe~1234")

@When(u"在登录界面点击登录")
def step_impl(context):
    login = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_login")))
    login.click()
    time.sleep(1)
    agree = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_sure")))
    agree.click()
    login = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_login")))
    login.click()
    time.sleep(3)

@Then(u"登录界面点击登录后进入App主界面")
def step_iml(context):
    time.sleep(3)
    number = 2
    for i in range(number):
        location_3 = ("xpath", "//*[@text='允许']")
        try:
            e = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_3))
            e.click()
        except:
            pass

    for i in range(number):
        location_4 = ("xpath", "//*[@text='始终允许']")
        try:
            e = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_4))
            e.click()
        except:
            pass

    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)

    for i in range(number):
        location_2 = ("xpath", "//*[@text='知道了']")
        try:
            notice_2 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_2))
            notice_2.click()
        except Exception as e:
            print(e)

    context.driver.implicitly_wait(1)


#--------------------Scenario:用户B在登录界面正常登录--------------------
@Given(u"用户B输入正确用户名和密码")
def step_impl(context):
    time.sleep(3)
    user_name = WebDriverWait(context.driver, 5, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
    user_name.clear()
    user_name.send_keys("cwx563946")
    password = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
    password.clear()
    password.send_keys("Huawei12#$")


#--------------------Scenario:用户C在登录界面正常登录--------------------
@Given(u"用户C输入正确用户名和密码")
def step_impl(context):
    time.sleep(3)
    user_name = WebDriverWait(context.driver, 5, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
    user_name.clear()
    user_name.send_keys("lwx532173")
    password = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
    password.clear()
    password.send_keys("luoBIN@123")


#--------------------Scenario:用户D在登录界面正常登录--------------------
@Given(u"用户D输入正确用户名和密码")
def step_impl(context):
    time.sleep(3)
    user_name = WebDriverWait(context.driver, 5, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
    user_name.clear()
    user_name.send_keys("dwx317357")
    password = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
    password.clear()
    password.send_keys("nh...456")


#--------------------Scenario:点击底部导航栏进入个人中心--------------------
@When(u"底部导航栏点击个人中心")
def step_impl(context):
    time.sleep(3)
    tab_1 = context.driver.find_element_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='个人中心']"))
    tab_1.click()

@Then(u"进入个人中心界面")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:进入个人中心界面退出登录--------------------
@When(u"在个人中心界面点击设置")
def step_impl(context):
    time.sleep(1)
    setting = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/rl_setting")))
    setting.click()

@When(u"在设置界面点击退出登录")
def step_impl(context):
    time.sleep(1)
    logout = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_logout")))
    logout.click()

@When(u"在设置界面弹出退出登录的对话框点击确定按钮")
def step_impl(context):
    sure = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_dialog_sure")))
    sure.click()

@Then(u"退出登录，退回到登录界面")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在详情界面添加照片--------------------
@When(u"在详情界面点击添加照片按钮")
def step_impl(context):
    time.sleep(3)
    Tool.BaseClass.swipeUp(context.driver)
    add_photo = context.driver.find_element_by_id(("com.huawei.ioc:id/iv_item_photo"))
    add_photo.click()

    choose_albu = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_choose_album"))
    choose_albu.click()

@When(u"在相册照片列表界面点击照片添加")
def step_impl(context):
    select_icon = context.driver.find_elements_by_xpath(
        ("//android.widget.ImageView[@resource-id='com.huawei.ioc:id/iv_select_icon']"))
    select_photo = select_icon[0]
    select_photo.click()

    right = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_right"))
    right.click()

@Then(u"详情界面上显示勾选的照片")
def step_impl(context):
    context.driver.implicitly_wait(1)