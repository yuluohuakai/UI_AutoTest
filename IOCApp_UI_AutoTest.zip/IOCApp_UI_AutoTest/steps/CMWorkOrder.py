import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import Tool


#--------------------Scenario:进入CM工单界面，查看CM工单列表--------------------
@When(u"在个人中心界面点击工单管理")
def step_impl(context):
    time.sleep(3)
    work_order_manger = context.driver.find_element_by_id("com.huawei.ioc:id/rl_work_order_manger")
    work_order_manger.click()

@When(u"在底部导航栏点击CM工单")
def step_impl(context):
    time.sleep(3)
    tab_3 = context.driver.find_element_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='CM工单']"))
    tab_3.click()

@Then(u"进入CM工单界面，显示CM工单列表")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在CM工单界面下拉刷新加载CM工单列表--------------------
@When(u"在CM工单界面下拉刷新")
def step_impl(context):
    time.sleep(5)
    Tool.BaseClass.swipeDown(context.driver)
    time.sleep(3)

@Then(u"刷新加载CM工单列表")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在CM工单界面选择未接受的工单--------------------
@When(u"CM工单列表中选择未接受的CM工单")
def step_impl(context):
    time.sleep(10)
    tab_1 = context.driver.find_elements_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept' and @text='接受']/../.."))
    if(len(tab_1)>0):
        tab_2 = tab_1[0]
        tab_2.click()
    else:
        number = 3
        for i in range(number):
            Tool.BaseClass.swipeUp(context.driver, 500, 1, 0.75, 0.35)
            time.sleep(3)
            tab_1 = context.driver.find_elements_by_xpath(
                ("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept' and @text='接受']/../.."))
            if (len(tab_1) > 0):
                tab_2 = tab_1[0]
                tab_2.click()
                break

@Then(u"进入CM工单详情界面")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在CM工单详情页面点击接受CM工单--------------------
@When(u"在CM工单详情页面点击接受")
def step_impl(context):
    time.sleep(10)
    accept = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_accept")))
    accept.click()
    time.sleep(8)


#--------------------Scenario:在CM工单详情界面点击转发工单--------------------
@When(u"在CM工单详情页面点击转发")
def step_impl(context):
    time.sleep(10)
    transpond = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_transpond")))
    transpond.click()
    time.sleep(6)

@When(u"在CM工单的选择被转发人列表界面选择被转发人员")
def step_impl(context):
    time.sleep(10)
    search = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_search_text")))
    search.click()
    search_name = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/etsearch_name")))
    search_name.send_keys("dwx317357")
    search_icon = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/iv_search_icon")))
    search_icon.click()

@When(u"在CM工单的选择被转发人列表界面点击完成")
def step_impl(context):
    time.sleep(1)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_right")))
    sure.click()

@When(u"在CM工单的选择被转发人列表界面弹出的被转发人对话框中点击确定")
def step_impl(context):
    time.sleep(1)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_dialog_sure")))
    sure.click()
    time.sleep(6)

@When(u"在CM工单的选择被转发人列表界面弹出的已转发对话框中点击返回我的工单")
def step_impl(context):
    time.sleep(3)
    finish = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_finish")))
    finish.click()
    time.sleep(3)

@Then(u"从被转发人界面返回到CM工单界面，显示CM工单列表")
def step_impl(context):
    time.sleep(3)
    number = 2
    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)


#--------------------Scenario:在CM工单详情页面暂缓执行CM工单--------------------
@When(u"在CM工单详情页面点击暂缓执行")
def step_impl(context):
    time.sleep(15)
    tab = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_accept")))
    tab.click()

@When(u"在CM工单详情页面的暂缓执行原因框中点击确定")
def step_impl(context):
    time.sleep(6)
    sure = context.driver.find_element_by_id("com.huawei.ioc:id/tv_wheel_view_sure")
    sure.click()
    time.sleep(6)


#--------------------Scenario:在CM工单列表页面选择暂缓执行的CM工单--------------------
@When(u"在CM工单列表页面选择暂缓执行的工单")
def step_impl(context):
    time.sleep(10)
    tab_1 = context.driver.find_elements_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='等待排程']"))
    if (len(tab_1) > 0):
        tab_2 = tab_1[0]
        tab_2.click()
    else:
        number = 3
        for i in range(number):
            Tool.BaseClass.swipeUp(context.driver, 500, 1, 0.75, 0.35)
            time.sleep(3)
            tab_1 = context.driver.find_elements_by_xpath(
                ("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='等待排程']"))
            if (len(tab_1) > 0):
                tab_2 = tab_1[0]
                tab_2.click()
                break


#--------------------Scenario:在CM工单列表页面选择暂缓执行的CM工单继续执行--------------------
@When(u"在CM工单列表页面点击继续执行")
def step_impl(context):
    time.sleep(10)
    tab = context.driver.find_element_by_id("com.huawei.ioc:id/tv_accept")
    tab.click()
    time.sleep(3)


#--------------------Scenario:在CM工单详情页面添加设备--------------------
@When(u"在CM工单详情页面点击添加设备")
def step_impl(context):
    time.sleep(10)
    add_device = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_add_device")))
    add_device.click()

@When(u"在CM工单的设备列表页面选择设备")
def step_impl(context):
    time.sleep(3)
    devices = context.driver.find_elements_by_id(("com.huawei.ioc:id/iv_arrow_right"))
    if(len(devices)>0):
        device = devices[0]
        device.click()

@When(u"在CM工单的设备详情页面点击添加")
def step_impl(context):
    time.sleep(1)
    add_device = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_add_device")))
    add_device.click()
    time.sleep(6)


#--------------------Scenario:在CM工单详情页面添加物料--------------------
@When(u"在CM工单详情页面点击添加物料")
def step_impl(context):
    time.sleep(10)
    Tool.BaseClass.swipeUp(context.driver, 500, 1, 0.75, 0.35)
    add_materials = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_add_materials")))
    add_materials.click()

@When(u"在CM工单的物料列表页面选择物料")
def step_impl(context):
    time.sleep(3)
    materials = context.driver.find_elements_by_id(("com.huawei.ioc:id/iv_arrow_right"))
    if(len(materials)>0):
        material = materials[0]
        material.click()

@When(u"在CM工单的物料详情页面填写预定数量并添加")
def step_impl(context):
    time.sleep(1)
    material_count = context.driver.find_element_by_id("com.huawei.ioc:id/et_material_count")
    material_count.send_keys("1")
    add_material = context.driver.find_element_by_id("com.huawei.ioc:id/btn_add_material")
    add_material.click()
    time.sleep(10)

#--------------------Scenario:在CM工单详情页面添加工作分析--------------------
@When(u"在CM工单详情页面的工作分析栏点击添加")
def step_impl(context):
    time.sleep(10)
    Tool.BaseClass.swipeUp(context.driver)
    work_order_analysis = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_work_order_analysis_status")))
    work_order_analysis.click()

@When(u"在工作分析页面点击选择故障")
def step_impl(context):
    time.sleep(1)
    select_malfunction = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/rl_select_malfunction")))
    select_malfunction.click()

@When(u"在选择故障页面点击返回")
def step_impl(context):
    time.sleep(1)
    back = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_left")))
    back.click()

@When(u"在工作分析页面点击选择问题")
def step_impl(context):
    time.sleep(1)
    select_problem = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/rl_select_problem")))
    select_problem.click()

@When(u"在选择问题页面点击问题")
def step_impl(context):
    time.sleep(3)
    items = context.driver.find_elements_by_id("com.huawei.ioc:id/check_box")
    if(len(items)>0):
        item = items[0]
        item.click()

@When(u"在选择问题页面点击确定")
def step_impl(context):
    time.sleep(1)
    sure = context.driver.find_element_by_id("com.huawei.ioc:id/tv_right")
    sure.click()

@When(u"在工作分析页面点击选择原因")
def step_impl(context):
    time.sleep(3)
    select_reason = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_select_reason")))
    select_reason.click()

@When(u"在选择原因页面点击返回")
def step_impl(context):
    time.sleep(1)
    back = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_left")))
    back.click()

@When(u"在工作分析页面点击保存")
def step_impl(context):
    sure = context.driver.find_element_by_id("com.huawei.ioc:id/tv_right")
    sure.click()
    time.sleep(8)


#--------------------Scenario:在CM工单详情页面添加工时--------------------
@When(u"在CM工单详情页面的工时栏点击工作时间")
def step_impl(context):
    time.sleep(10)
    Tool.BaseClass.swipeUp(context.driver)
    work_time = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_work_time")))
    work_time.click()

@When(u"在CM工单详情页面的填写工时数页面填写工时")
def step_impl(context):
    time.sleep(3)
    work_time = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/edt_time")))
    work_time.clear()
    work_time.send_keys("1")

@When(u"在CM工单详情页面的填写工时数页面点击确定")
def step_impl(context):
    time.sleep(3)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_btn_sure")))
    sure.click()
    time.sleep(8)


#--------------------Scenario:在CM工单详情页面点击完成工单--------------------
@When(u"在CM工单详情页面点击完成")
def step_impl(context):
    time.sleep(10)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_right")))
    sure.click()


#--------------------Scenario:在CM工单详情页面弹出的确定完成对话框点击确定--------------------
@When(u"在CM工单详情页面的确定完成对话框点击确定")
def step_impl(context):
    time.sleep(3)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_dialog_sure")))
    sure.click()
    time.sleep(6)