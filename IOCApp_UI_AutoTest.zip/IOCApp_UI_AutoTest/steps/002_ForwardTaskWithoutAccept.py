import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import Tool
import Const


#--------------------Scenario:人员A正常登录Feature_02--------------------
@Given(u"输入正确用户名和密码Feature_02")
def step_impl(context):
    user_name = WebDriverWait(context.driver, 5, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
    user_name.send_keys("test1")
    password = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
    password.send_keys("Pr0d1234")

@When(u"点击登录Feature_02")
def step_impl(context):
    login = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_login")))
    login.click()

@Then(u"进入App主界面Feature_02")
def step_iml(context):
    context.driver.implicitly_wait(2)
    number = 2
    for i in range(number):
        location_3 = ("xpath", "//*[@text='允许']")
        try:
            e = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_3))
            e.click()
        except:
            pass

    for i in range(number):
        location_4 = ("xpath", "//*[@text='始终允许']")
        try:
            e = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_4))
            e.click()
        except:
            pass

    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)

    for i in range(number):
        location_2 = ("xpath", "//*[@text='知道了']")
        try:
            notice_2 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_2))
            notice_2.click()
        except Exception as e:
            print(e)

    context.driver.implicitly_wait(1)


#--------------------Scenario:进入个人中心Feature_02--------------------
@When(u"点击个人中心Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(3)
    tab_1 = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located(
        (By.XPATH, "//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='个人中心']")))
    tab_1.click()

@Then(u"进入个人中心界面Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)


#--------------------Scenario:进入任务列表Feature_02--------------------
@When(u"点击事件管理Feature_02")
def step_impl(context):
    tab_2 = context.driver.find_element_by_id("com.huawei.ioc:id/rl_event_manger")
    tab_2.click()

@When(u"点击我的任务Feature_02")
def step_impl(context):
    tab_3 = context.driver.find_element_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='我的任务']"))
    tab_3.click()

@Then(u"进入我的任务Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)


#--------------------Scenario:下拉刷新加载事件列表Feature_02--------------------
@When(u"下拉刷新Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(5)
    Tool.BaseClass.swipeDown(context.driver)
    time.sleep(5)
    print("Hello")

@Then(u"加载事件列表Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(5)


#--------------------Scenario:转发未接受的任务Feature_02--------------------
@When(u"选择未接受的任务Feature_02")
def step_impl(context):
    tab_1 = context.driver.find_elements_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='接受']/.."))
    if(len(tab_1)>0):
        tab_2 = tab_1[0]
        tab_2.click()
    else:
        number = 2
        for i in range(number):
            Tool.BaseClass.swipeUp(context.driver)
            tab_1 = context.driver.find_elements_by_xpath(
                ("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='接受']/.."))
            if (len(tab_1) > 0):
                tab_2 = tab_1[0]
                tab_2.click()
                break

@When(u"在详情页面点击转发Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(5)
    transpond = WebDriverWait(context.driver, 5, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_transpond")))
    transpond.click()
    context.driver.implicitly_wait(5)

@When(u"在被转发人列表选择人员Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(8)
    name = ("xpath", "//android.widget.TextView[@text='caojin (D)  c84108434']")
    person = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((name)))
    person.click()
    context.driver.implicitly_wait(5)

@When(u"点击确定Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_right")))
    sure.click()
    context.driver.implicitly_wait(5)

@When(u"点击返回我的任务Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_finish")))
    sure.click()
    context.driver.implicitly_wait(3)

@Then(u"返回任务列表Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(2)
    number = 2
    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)
    context.driver.implicitly_wait(3)


#--------------------Scenario:进入个人中心退出登录Feature_02--------------------
'''
@When(u"点击个人中心Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(3)
    tab_1 = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located(
        (By.XPATH, "//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='个人中心']")))
    tab_1.click()
'''

@When(u"点击设置Feature_02")
def step_impl(context):
    setting = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/rl_setting")))
    setting.click()

@When(u"点击退出登录Feature_02")
def step_impl(context):
    logout = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_logout")))
    logout.click()

@When(u"点击个人中心界面的对话框的确定按钮Feature_02")
def step_impl(context):
    sure = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_dialog_sure")))
    sure.click()

@Then(u"回到登录界面Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)



#--------------------Scenario:人员B正常登录Feature_02--------------------
@Given(u"人员B输入正确用户名和密码Feature_02")
def step_impl(context):
    user_name = WebDriverWait(context.driver, 5, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
    user_name.clear()
    user_name.send_keys("c84108434")
    password = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
    password.clear()
    password.send_keys("qwe~1234")

@When(u"人员B点击登录Feature_02")
def step_impl(context):
    login = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_login")))
    login.click()

@Then(u"人员B进入App主界面Feature_02")
def step_iml(context):
    context.driver.implicitly_wait(2)
    number = 2
    for i in range(number):
        location_3 = ("xpath", "//*[@text='允许']")
        try:
            e = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_3))
            e.click()
        except:
            pass

    for i in range(number):
        location_4 = ("xpath", "//*[@text='始终允许']")
        try:
            e = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_4))
            e.click()
        except:
            pass

    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)

    for i in range(number):
        location_2 = ("xpath", "//*[@text='知道了']")
        try:
            notice_2 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_2))
            notice_2.click()
        except Exception as e:
            print(e)

    context.driver.implicitly_wait(1)


#--------------------Scenario:进入个人中心Feature_02--------------------
'''
@When(u"点击个人中心Feature_02")
def step_impl(context):
    tab_1 = context.driver.find_element_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='个人中心']"))
    tab_1.click()

@Then(u"进入个人中心界面Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)

#--------------------Scenario:进入任务列表Feature_02--------------------
@When(u"点击事件管理Feature_02")
def step_impl(context):
    tab_2 = context.driver.find_element_by_id("com.huawei.ioc:id/rl_event_manger")
    tab_2.click()

@When(u"点击我的任务Feature_02")
def step_impl(context):
    tab_3 = context.driver.find_element_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='我的任务']"))
    tab_3.click()

@Then(u"进入我的任务Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)


#--------------------Scenario:下拉刷新加载事件列表Feature_02--------------------
@When(u"下拉刷新Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(5)
    Tool.BaseClass.swipeDown(context.driver)
    time.sleep(5)
    print("Hello")

@Then(u"加载事件列表Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(5)


#--------------------Scenario:选择未接受的任务Feature_02--------------------
@When(u"选择未接受的任务Feature_02")
def step_impl(context):
    tab_1 = context.driver.find_elements_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='接受']/.."))
    if(len(tab_1)>0):
        tab_2 = tab_1[0]
        tab_2.click()
    else:
        number = 2
        for i in range(number):
            Tool.BaseClass.swipeUp(context.driver)
            tab_1 = context.driver.find_elements_by_xpath(
                ("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='接受']/.."))
            if (len(tab_1) > 0):
                tab_2 = tab_1[0]
                tab_2.click()
                break
'''

@When(u"在详情页面点击接受Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)
    accept = context.driver.find_element_by_id("com.huawei.ioc:id/tv_accept")
    accept.click()
    context.driver.implicitly_wait(5)

@Then(u"进入任务详情界面Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(0.5)


#--------------------Scenario:填写现场反馈Feature_02--------------------
@When(u"点击现场反馈选项Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(5)
    tab_3 = context.driver.find_element_by_xpath(("//android.widget.TextView[@text='真实事件，已处理']"))
    tab_3.click()
    context.driver.implicitly_wait(3)

@Then(u"勾选选项Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)

'''
#--------------------Scenario:添加照片Feature_02--------------------
@When(u"点击添加照片按钮Feature_02")
def step_impl(context):
    Tool.BaseClass.swipeUp(context.driver)
    add_photo = context.driver.find_element_by_id(("com.huawei.ioc:id/iv_item_photo"))
    add_photo.click()

    choose_albu = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_choose_album"))
    choose_albu.click()

@When(u"点击照片添加Feature_02")
def step_impl(context):
    select_icon = context.driver.find_elements_by_xpath(
        ("//android.widget.ImageView[@resource-id='com.huawei.ioc:id/iv_select_icon']"))
    select_photo = select_icon[0]
    select_photo.click()

    right = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_right"))
    right.click()

@Then(u"界面上含有照片Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)
'''

#--------------------Scenario:填写备注Feature_02--------------------
@When(u"填写备注Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(3)
    Tool.BaseClass.swipeUp(context.driver)
    upload_des = context.driver.find_element_by_id(("com.huawei.ioc:id/et_upload_des"))
    upload_des.send_keys("完成")
    context.driver.implicitly_wait(0.5)

@Then(u"界面上出现备注信息Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)


#--------------------Scenario:完成任务Feature_02--------------------
@When(u"点击完成Feature_02")
def step_impl(context):
    finish = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_finish"))
    finish.click()
    context.driver.implicitly_wait(3)

@Then(u"返回到任务列表界面Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(1)


#--------------------Scenario:查看已办任务Feature_02--------------------
@When(u"点击已办任务Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(2)
    number = 2
    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)
    bt_1 = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/iv_right_right")))
    bt_1.click()
    bt_2 =WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_event_history")))
    bt_2.click()
    time.sleep(5)

@Then(u"查看任务Feature_02")
def step_impl(context):
    context.driver.implicitly_wait(3)