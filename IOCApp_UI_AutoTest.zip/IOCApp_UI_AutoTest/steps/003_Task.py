import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import Tool
import Const



#--------------------Scenario:用户A在登录界面正常登录--------------------
@Given(u"用户A输入正确用户名和密码")
def step_impl(context):
    time.sleep(3)
    user_name = WebDriverWait(context.driver, 5, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
    user_name.clear()
    user_name.send_keys("c84108434")
    password = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
    password.clear()
    password.send_keys("qwe~1234")

@When(u"在登录界面点击登录")
def step_impl(context):
    login = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_login")))
    login.click()

@Then(u"登录界面点击登录后进入App主界面")
def step_iml(context):
    time.sleep(3)
    number = 2
    for i in range(number):
        location_3 = ("xpath", "//*[@text='允许']")
        try:
            e = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_3))
            e.click()
        except:
            pass

    for i in range(number):
        location_4 = ("xpath", "//*[@text='始终允许']")
        try:
            e = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_4))
            e.click()
        except:
            pass

    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)

    for i in range(number):
        location_2 = ("xpath", "//*[@text='知道了']")
        try:
            notice_2 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_2))
            notice_2.click()
        except Exception as e:
            print(e)

    context.driver.implicitly_wait(1)


#--------------------Scenario:用户B在登录界面正常登录--------------------
@Given(u"用户B输入正确用户名和密码")
def step_impl(context):
    time.sleep(3)
    user_name = WebDriverWait(context.driver, 5, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
    user_name.clear()
    user_name.send_keys("cwx563946")
    password = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
    password.clear()
    password.send_keys("Huawei12#$")


#--------------------Scenario:点击底部导航栏进入个人中心--------------------
@When(u"底部导航栏点击个人中心")
def step_impl(context):
    time.sleep(3)
    tab_1 = context.driver.find_element_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='个人中心']"))
    tab_1.click()

@Then(u"进入个人中心界面")
def step_impl(context):
    time.sleep(1)

#--------------------Scenario:进入我的任务界面，查看任务列表--------------------
@When(u"在个人中心界面点击事件管理")
def step_impl(context):
    time.sleep(3)
    tab_2 = context.driver.find_element_by_id("com.huawei.ioc:id/rl_event_manger")
    tab_2.click()

@When(u"在底部导航栏点击我的任务")
def step_impl(context):
    time.sleep(3)
    tab_3 = context.driver.find_element_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='我的任务']"))
    tab_3.click()

@Then(u"进入我的任务界面，显示任务列表")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在我的任务界面下拉刷新加载事件列表--------------------
@When(u"在我的任务界面下拉刷新")
def step_impl(context):
    time.sleep(5)
    Tool.BaseClass.swipeDown(context.driver)
    time.sleep(1)

@Then(u"刷新加载事件列表")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在我的任务界面选择未接受的任务--------------------
@When(u"事件列表中选择未接受的任务")
def step_impl(context):
    time.sleep(10)
    tab_1 = context.driver.find_elements_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='接受']/.."))
    if(len(tab_1)>0):
        tab_2 = tab_1[0]
        tab_2.click()
    else:
        number = 3
        for i in range(number):
            Tool.BaseClass.swipeUp(context.driver)
            time.sleep(3)
            tab_1 = context.driver.find_elements_by_xpath(
                ("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='接受']/.."))
            if (len(tab_1) > 0):
                tab_2 = tab_1[0]
                tab_2.click()
                break

@Then(u"进入任务详情界面")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在任务详情界面点击接受任务--------------------
@When(u"在任务详情页面点击接受")
def step_impl(context):
    time.sleep(10)
    accept = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_accept")))
    accept.click()


#--------------------Scenario:在任务详情界面点击拒绝任务--------------------
@When(u"在任务详情页面点击拒绝")
def step_impl(context):
    time.sleep(10)
    accept = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_finish")))
    accept.click()

@When(u"在填写拒绝原因页面填写原因")
def step_impl(context):
    time.sleep(3)
    description = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_problem_des")))
    description.clear()
    description.send_keys("请派发此任务给其他人执行")

@When(u"在填写拒绝原因页面点击确定")
def step_impl(context):
    time.sleep(3)
    sure = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_right")))
    sure.click()


#--------------------Scenario:在任务详情界面点击转发任务--------------------
@When(u"在任务详情页面点击转发")
def step_impl(context):
    time.sleep(10)
    transpond = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_transpond")))
    transpond.click()
    context.driver.implicitly_wait(5)

@When(u"在选择被转发人列表界面选择被转发人员")
def step_impl(context):
    time.sleep(10)
    name = ("xpath", "//android.widget.TextView[@text='chenyouli  cwx563946']")
    person = WebDriverWait(context.driver, 10, 0.5).until(EC.presence_of_element_located(name))
    person.click()

@When(u"在选择被转发人列表界面点击完成")
def step_impl(context):
    time.sleep(5)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_right")))
    sure.click()

@When(u"在选择被转发人列表界面弹出的对话框中点击返回我的任务")
def step_impl(context):
    time.sleep(5)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_finish")))
    sure.click()

@Then(u"从被转发人界面返回到我的任务界面，显示任务列表")
def step_impl(context):
    time.sleep(3)
    number = 2
    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)

#--------------------Scenario:在任务详情界面填写现场反馈--------------------
@When(u"在任务详情界面点击现场反馈选项")
def step_impl(context):
    time.sleep(10)
    Tool.BaseClass.swipeUp(context.driver, 500, 1, 0.75, 0.5)
    tab_3 = context.driver.find_element_by_xpath(("//android.widget.TextView[@text='真实事件，已处理']"))
    tab_3.click()

@Then(u"点击现场反馈选项后成功勾选选项")
def step_impl(context):
    time.sleep(1)


'''
#--------------------Scenario:在任务详情界面添加照片--------------------
@When(u"在任务详情界面点击添加照片按钮")
def step_impl(context):
    Tool.BaseClass.swipeUp(context.driver)
    add_photo = context.driver.find_element_by_id(("com.huawei.ioc:id/iv_item_photo"))
    add_photo.click()

    choose_albu = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_choose_album"))
    choose_albu.click()

@When(u"在照片列表界面点击照片添加")
def step_impl(context):
    select_icon = context.driver.find_elements_by_xpath(
        ("//android.widget.ImageView[@resource-id='com.huawei.ioc:id/iv_select_icon']"))
    select_photo = select_icon[0]
    select_photo.click()

    right = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_right"))
    right.click()

@Then(u"任务详情界面上显示勾选的照片")
def step_impl(context):
    context.driver.implicitly_wait(1)
'''


#--------------------Scenario:在任务详情界面填写备注--------------------
@When(u"在任务详情界面填写备注")
def step_impl(context):
    time.sleep(10)
    Tool.BaseClass.swipeUp(context.driver, 500, 1, 0.75, 0.35)
    upload_des = context.driver.find_element_by_id(("com.huawei.ioc:id/et_upload_des"))
    upload_des.send_keys("完成")

@Then(u"任务详情界面上出现备注信息")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在任务详情界面点击完成任务--------------------
@When(u"在任务详情界面点击完成按钮")
def step_impl(context):
    finish = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_finish"))
    finish.click()
    time.sleep(10)

@Then(u"返回到我的任务界面，显示任务列表")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:查看已办任务列表--------------------
@When(u"在我的任务界面点击已办任务")
def step_impl(context):
    time.sleep(3)
    number = 2
    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)
    bt_1 = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/iv_right_right")))
    bt_1.click()
    bt_2 =WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_event_history")))
    bt_2.click()

@Then(u"查看已办任务")
def step_impl(context):
    time.sleep(3)

@When(u"在已办任务界面点击返回")
def step_impl(context):
    time.sleep(3)
    back = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_left")))
    back.click()


#--------------------Scenario:进入个人中心界面退出登录--------------------
@When(u"在个人中心界面点击设置")
def step_impl(context):
    time.sleep(1)
    setting = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/rl_setting")))
    setting.click()

@When(u"在设置界面点击退出登录")
def step_impl(context):
    time.sleep(1)
    logout = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_logout")))
    logout.click()

@When(u"在设置界面弹出退出登录的对话框点击确定按钮")
def step_impl(context):
    sure = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_dialog_sure")))
    sure.click()

@Then(u"退出登录，退回到登录界面")
def step_impl(context):
    time.sleep(1)