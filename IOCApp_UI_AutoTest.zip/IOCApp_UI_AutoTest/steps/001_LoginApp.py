import time
from behave import *
from appium import webdriver

@Given(u"输入正确用户名和密码")
def step_impl(context):
    time.sleep(5)
    textfields_1 = context.driver.find_element_by_id("com.huawei.ioc:id/et_input_user_name")
    textfields_1.send_keys("test1")
    textfields_2 = context.driver.find_element_by_id("com.huawei.ioc:id/et_password")
    textfields_2.send_keys("Pr0d1234")

@When(u"点击登录")
def step_impl(context):
    el = context.driver.find_element_by_id("com.huawei.ioc:id/btn_login")
    el.click()
    time.sleep(5)

@Then(u"进入App主界面")
def step_iml(context):
    time.sleep(5)