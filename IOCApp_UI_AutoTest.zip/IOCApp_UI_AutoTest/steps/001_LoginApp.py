import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


@Given(u"输入正确用户名和密码")
def step_impl(context):
    user_name = WebDriverWait(context.driver, 5, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
    user_name.send_keys("test1")
    password = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
    password.send_keys("Pr0d1234")
    '''
    textfields_1 = context.driver.find_element_by_id("com.huawei.ioc:id/et_input_user_name")
    textfields_1.send_keys("test1")
    textfields_2 = context.driver.find_element_by_id("com.huawei.ioc:id/et_password")
    textfields_2.send_keys("Pr0d1234")
    '''
@When(u"点击登录")
def step_impl(context):
    '''
    el = context.driver.find_element_by_id("com.huawei.ioc:id/btn_login")
    el.click()
    time.sleep(5)
    '''
    login = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_login")))
    login.click()

@Then(u"进入App主界面")
def step_iml(context):

    context.driver.implicitly_wait(2)
    number = 2
    for i in range(number):
        loc = ("xpath", "//*[@text='允许']")
        try:
            e = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(loc))
            e.click()
        except:
            pass

    for i in range(number):
        loc = ("xpath", "//*[@text='始终允许']")
        try:
            e = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(loc))
            e.click()
        except:
            pass

    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)

    for i in range(number):
        location_2 = ("xpath", "//*[@text='知道了']")
        try:
            notice_2 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_2))
            notice_2.click()
        except Exception as e:
            print(e)

    context.driver.implicitly_wait(1)
