import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


@Given(u"输入正确用户名和密码")
def step_impl(context):
    try:
        user_name = WebDriverWait(context.driver, 5, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
        user_name.send_keys("test1")
    except:
        print("NoSuchElement")
    try:
        password = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
        password.send_keys("Pr0d1234")
    except:
        print("NoSuchElement")
    '''
    textfields_1 = context.driver.find_element_by_id("com.huawei.ioc:id/et_input_user_name")
    textfields_1.send_keys("test1")
    textfields_2 = context.driver.find_element_by_id("com.huawei.ioc:id/et_password")
    textfields_2.send_keys("Pr0d1234")
    '''
@When(u"点击登录")
def step_impl(context):
    '''
    el = context.driver.find_element_by_id("com.huawei.ioc:id/btn_login")
    el.click()
    time.sleep(5)
    '''
    try:
        login = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_login")))
        login.click()
    except:
        print("NoSuchElement")

@Then(u"进入App主界面")
def step_iml(context):

    number = 2
    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)

    for i in range(number):
        location_2 = ("xpath", "//*[@text='知道了']")
        try:
            notice_2 = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located(location_2))
            notice_2.click()
        except Exception as e:
            print(e)

    context.driver.implicitly_wait(1)
