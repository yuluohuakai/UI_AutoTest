import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


@Given(u"输入正确用户名和密码")
def step_impl(context):
    time.sleep(5)
    try:
        element_1 = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_user_name")))
        element_1.send_keys("test1")
    except:
        print("NoSuchElement")
    try:
        element_2 = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_password")))
        element_2.send_keys("Pr0d1234")
    except:
        print("NoSuchElement")
    '''
    textfields_1 = context.driver.find_element_by_id("com.huawei.ioc:id/et_input_user_name")
    textfields_1.send_keys("test1")
    textfields_2 = context.driver.find_element_by_id("com.huawei.ioc:id/et_password")
    textfields_2.send_keys("Pr0d1234")
    '''
@When(u"点击登录")
def step_impl(context):
    '''
    el = context.driver.find_element_by_id("com.huawei.ioc:id/btn_login")
    el.click()
    time.sleep(5)
    '''
    try:
        element_3 = WebDriverWait(context.driver, 3, 1).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_login")))
        element_3.click()
    except:
        print("NoSuchElement")

@Then(u"进入App主界面")
def step_iml(context):
    time.sleep(5)