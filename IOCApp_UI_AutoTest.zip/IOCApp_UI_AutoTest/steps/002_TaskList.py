from behave import *
import Tool
import time


#--------------------Scenario:进入个人中心--------------------
@When(u"点击个人中心")
def step_impl(context):

    try:
        tab_1 = context.driver.find_element_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='个人中心']"))
        tab_1.click()
    except Exception as e:
        print(e)

@Then(u"进入个人中心界面")
def step_impl(context):
    context.driver.implicitly_wait(1)


#--------------------Scenario:进入任务列表--------------------
@When(u"点击事件管理")
def step_impl(context):

    try:
        tab_2 = context.driver.find_element_by_id("com.huawei.ioc:id/rl_event_manger")
        tab_2.click()
    except Exception as e:
        print(e)

@When(u"点击我的任务")
def step_impl(context):

    try:
        tab_3 = context.driver.find_element_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='我的任务']"))
        tab_3.click()
    except Exception as e:
        print(e)

@Then(u"进入我的任务")
def step_impl(context):
    context.driver.implicitly_wait(1)


#--------------------Scenario:下拉刷新加载事件列表--------------------
@When(u"下拉刷新")
def step_impl(context):
    context.driver.implicitly_wait(5)
    Tool.BaseClass.swipeDown(context.driver)
    time.sleep(5)
    print("Hello")


@Then(u"加载事件列表")
def step_impl(context):
    context.driver.implicitly_wait(5)