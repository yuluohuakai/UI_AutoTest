import time
from appium.webdriver import *
import unittest

class BaseClass(unittest.TestCase):

    @staticmethod
    def LoginForAuto(driver):
        #登录名和密码
        userName="test1"
        passWord="Pr0d1234"

    # 获取屏幕宽和高
    @staticmethod
    def getSize(driver):
        x = driver.driver.get_window_size()['width']
        y = driver.get_window_size()['height']
        return (x, y)

    # 向左滑动
    @staticmethod
    def swipeLeft(self, t):
        l = self.getSize()
        x1 = int(l[0] * 0.75)
        y1 = int(l[1] * 0.5)
        x2 = int(l[0] * 0.25)
        self.driver.swipe(x1, y1, x2, y1, t)

    # 向右滑动
    @staticmethod
    def swipeRight(self, t):
        l = self.getSize()
        x1 = int(l[0] * 0.25)
        y1 = int(l[1] * 0.5)
        x2 = int(l[0] * 0.75)
        self.driver.swipe(x1, y1, x2, y1, t)

    def swipeUp(driver, t=500, n=1):
        '''向上滑动屏幕'''
        l = driver.get_window_size()
        x1 = l['width'] * 0.5  # x坐标
        y1 = l['height'] * 0.75  # 起始y坐标
        y2 = l['height'] * 0.25  # 终点y坐标
        for i in range(n):
            driver.swipe(x1, y1, x1, y2, t)

    def swipeDown(driver, t=500, n=1):
        '''向下滑动屏幕'''
        l = driver.get_window_size()
        x1 = l['width'] * 0.5  # x坐标
        y1 = l['height'] * 0.25  # 起始y坐标
        y2 = l['height'] * 0.75  # 终点y坐标
        for i in range(n):
            driver.swipe(x1, y1, x1, y2, t)


