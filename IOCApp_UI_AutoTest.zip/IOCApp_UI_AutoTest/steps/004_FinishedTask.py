import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import Tool


#--------------------Scenario:查看已办任务--------------------
@When(u"点击已办任务")
def step_impl(context):
    context.driver.implicitly_wait(2)
    number = 2
    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)
    bt_1 = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/iv_right_right")))
    bt_1.click()
    bt_2 =WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_event_history")))
    bt_2.click()
    time.sleep(5)

@Then(u"查看任务")
def step_impl(context):
    context.driver.implicitly_wait(3)