import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import Tool


#--------------------Scenario:查看已办任务--------------------
@When(u"点击已办任务")
def step_impl(context):
    try:
        bt_1 = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/iv_right_right")))
        bt_1.click()
    except Exception as e:
        print(e)
    try:
        bt_2 =WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_event_history")))
        bt_2.click()
    except Exception as e:
        print(e)
    time.sleep(5)

@Then(u"查看任务")
def step_impl(context):
    context.driver.implicitly_wait(3)