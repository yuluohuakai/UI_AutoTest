import time
from behave import *
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import Tool


#--------------------Scenario:进入我的任务界面，查看任务列表--------------------
@When(u"在个人中心界面点击事件管理")
def step_impl(context):
    time.sleep(3)
    tab_2 = context.driver.find_element_by_id("com.huawei.ioc:id/rl_event_manger")
    tab_2.click()

@When(u"在底部导航栏点击我的任务")
def step_impl(context):
    time.sleep(3)
    tab_3 = context.driver.find_element_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_tab_text' and @text='我的任务']"))
    tab_3.click()

@Then(u"进入我的任务界面，显示任务列表")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在我的任务界面下拉刷新加载事件列表--------------------
@When(u"在我的任务界面下拉刷新")
def step_impl(context):
    time.sleep(5)
    Tool.BaseClass.swipeDown(context.driver)
    time.sleep(1)

@Then(u"刷新加载事件列表")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在我的任务界面选择未接受的任务--------------------
@When(u"事件列表中选择未接受的任务")
def step_impl(context):
    time.sleep(10)
    tasks = context.driver.find_elements_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='接受']/.."))
    if(len(tasks)>0):
        task = tasks[0]
        task.click()
    else:
        number = 3
        for i in range(number):
            Tool.BaseClass.swipeUp(context.driver)
            time.sleep(3)
            tasks = context.driver.find_elements_by_xpath(
                ("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='接受']/.."))
            if (len(tasks) > 0):
                task = tasks[0]
                task.click()
                break

@Then(u"进入任务详情界面")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在任务详情界面点击接受任务--------------------
@When(u"在任务详情页面点击接受")
def step_impl(context):
    time.sleep(10)
    accept = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_accept")))
    accept.click()


#--------------------Scenario:在任务详情界面点击拒绝任务--------------------

@When(u"在任务详情页面点击拒绝")
def step_impl(context):
    time.sleep(10)
    accept = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_finish")))
    accept.click()

@When(u"在填写拒绝原因页面填写原因")
def step_impl(context):
    time.sleep(3)
    description = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/et_input_problem_des")))
    description.clear()
    description.send_keys("请派发此任务给其他人执行")

@When(u"在填写拒绝原因页面点击确定")
def step_impl(context):
    time.sleep(3)
    sure = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_right")))
    sure.click()


#--------------------Scenario:在任务详情界面点击转发任务--------------------
@When(u"在任务详情页面点击转发")
def step_impl(context):
    time.sleep(10)
    transpond = WebDriverWait(context.driver, 8, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_transpond")))
    transpond.click()
    context.driver.implicitly_wait(5)

@When(u"在选择被转发人列表界面选择被转发人员")
def step_impl(context):
    time.sleep(10)
    name = ("xpath", "//android.widget.TextView[@text='chenyouli  cwx563946']")
    person = WebDriverWait(context.driver, 10, 0.5).until(EC.presence_of_element_located(name))
    person.click()

@When(u"在选择被转发人列表界面点击完成")
def step_impl(context):
    time.sleep(5)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_right")))
    sure.click()

@When(u"在选择被转发人列表界面弹出的对话框中点击返回我的任务")
def step_impl(context):
    time.sleep(5)
    sure = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_finish")))
    sure.click()

@Then(u"从被转发人界面返回到我的任务界面，显示任务列表")
def step_impl(context):
    time.sleep(3)
    number = 2
    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)


#--------------------Scenario:在任务详情界面填写现场反馈--------------------
@When(u"在任务详情界面点击现场反馈选项")
def step_impl(context):
    time.sleep(10)
    tab_3 = context.driver.find_element_by_xpath(("//android.widget.TextView[@text='真实事件，已处理']"))
    tab_3.click()

@Then(u"点击现场反馈选项后成功勾选选项")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在任务详情界面添加照片--------------------
@When(u"在任务详情界面点击添加照片按钮")
def step_impl(context):
    time.sleep(3)
    Tool.BaseClass.swipeUp(context.driver)
    add_photo = context.driver.find_element_by_id(("com.huawei.ioc:id/iv_item_photo"))
    add_photo.click()

    choose_albu = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_choose_album"))
    choose_albu.click()

@When(u"在照片列表界面点击照片添加")
def step_impl(context):
    select_icon = context.driver.find_elements_by_xpath(
        ("//android.widget.ImageView[@resource-id='com.huawei.ioc:id/iv_select_icon']"))
    select_photo = select_icon[0]
    select_photo.click()

    right = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_right"))
    right.click()

@Then(u"任务详情界面上显示勾选的照片")
def step_impl(context):
    context.driver.implicitly_wait(1)


#--------------------Scenario:在任务详情界面填写备注--------------------
@When(u"在任务详情界面填写备注")
def step_impl(context):
    time.sleep(10)
    Tool.BaseClass.swipeUp(context.driver, 500, 1, 0.75, 0.35)
    upload_des = context.driver.find_element_by_id(("com.huawei.ioc:id/et_upload_des"))
    upload_des.send_keys("完成")

@Then(u"任务详情界面上出现备注信息")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:在任务详情界面点击完成任务--------------------
@When(u"在任务详情界面点击完成按钮")
def step_impl(context):
    finish = context.driver.find_element_by_id(("com.huawei.ioc:id/tv_finish"))
    finish.click()
    time.sleep(10)

@Then(u"返回到我的任务界面，显示任务列表")
def step_impl(context):
    time.sleep(1)


#--------------------Scenario:查看已办任务列表--------------------
@When(u"在我的任务界面点击已办任务")
def step_impl(context):
    time.sleep(3)
    number = 2
    for i in range(number):
        location_1 = ("xpath", "//*[@text='暂不更新']")
        try:
            notice_1 = WebDriverWait(context.driver, 1, 0.5).until(EC.presence_of_element_located(location_1))
            notice_1.click()
        except Exception as e:
            print(e)
    bt_1 = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/iv_right_right")))
    bt_1.click()
    bt_2 =WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_event_history")))
    bt_2.click()

@Then(u"查看已办任务")
def step_impl(context):
    time.sleep(3)

@When(u"在已办任务列表中选择已关闭事件")
def step_impl(context):
    time.sleep(3)
    tab_1 = context.driver.find_elements_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='已关闭']/.."))
    if (len(tab_1) > 0):
        tab_2 = tab_1[0]
        tab_2.click()
    else:
        number = 3
        for i in range(number):
            Tool.BaseClass.swipeUp(context.driver, 500, 1, 0.75, 0.35)
            time.sleep(3)
            tab_1 = context.driver.find_elements_by_xpath(("//android.widget.TextView[@resource-id='com.huawei.ioc:id/tv_accept_status' and @text='已关闭']/.."))
            if (len(tab_1) > 0):
                tab_2 = tab_1[0]
                tab_2.click()
                break

@Then(u"查看已办任务的任务详情")
def step_impl(context):
    time.sleep(8)

@When(u"在已办任务的任务详情界面点击返回")
def step_impl(context):
    time.sleep(3)
    back = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_left")))
    back.click()

@When(u"在已办任务界面点击返回")
def step_impl(context):
    time.sleep(3)
    back = WebDriverWait(context.driver, 3, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/tv_left")))
    back.click()


