
class Constant:
    userName="test1"
    passWord="Pr0d1234"
