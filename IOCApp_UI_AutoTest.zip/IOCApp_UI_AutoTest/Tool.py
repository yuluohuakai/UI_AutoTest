import time
from appium.webdriver import *
import unittest

class BaseClass(unittest.TestCase):

    @staticmethod
    def LoginForAuto(driver):
        #登录名和密码
        userName="test1"
        passWord="Pr0d1234"
