import os
from appium import webdriver
from behave import *
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time


def before_all(context):
    #executor = context.config.userdata.get("executor",None)
    app = os.path.join(os.path.dirname(__file__),'test.apk')
    app = os.path.abspath(app)
    context.driver = webdriver.Remote(
        command_executor='http://127.0.0.1:4723/wd/hub',
        desired_capabilities={
            'platform':'Android',
            'version':'8.0.0',
            'platformName':'Android',
            'deviceName':'emulator-5554',
            #'deviceName': '9781ca80',
            #'deviceName': '6EB0217914002054',
            'newCommandTimeout':'5000',
            'appPackage':'com.huawei.ioc',
            'appActivity':'com.huawei.ioc.ui.activities.LoginActivity',
            #'automationName':'uiautomator2',
            'unicodeKeyboard':True,
            'resetKeyboard':True
        }
    )


    number = 2
    for i in range(number):
        try:
            agree = WebDriverWait(context.driver, 0.5, 0.5).until(EC.presence_of_element_located((By.ID, "com.huawei.ioc:id/btn_sure")))
            agree.click()
        except:
            pass


    number = 2
    for i in range(number):
        loc = ("xpath", "//*[@text='允许']")
        try:
            e = WebDriverWait(context.driver, 0.5, 0.5).until(EC.presence_of_element_located(loc))
            e.click()
        except:
            pass


    number = 3
    for i in range(number):
        loc = ("xpath", "//*[@text='始终允许']")
        try:
            e = WebDriverWait(context.driver, 0.5, 0.5).until(EC.presence_of_element_located(loc))
            e.click()
        except:
            pass

def after_all(context):
    context.driver.quit()